public enum TokenType {
    WHITESPACE,
    COEFICIENTE,
    VARIABLE,
    EXPONENTE,
    OPERADOR,
    LPAREN,
    RPAREN
}

