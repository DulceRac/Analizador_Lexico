import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class DotIO {
    public static void writeDot(String dot, Path dotPath) throws IOException {
        if (dotPath.getParent() != null) {
            Files.createDirectories(dotPath.getParent());
        }
        Files.write(dotPath, dot.getBytes(StandardCharsets.UTF_8));
    }
}

