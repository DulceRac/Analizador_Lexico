// package analizador;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

public class DiagramGenerator {

    // ========= AFN POR TOKEN =========
    public static String dotAFNCoeficiente() {
        return "digraph COEFICIENTE {\n" +
               "  rankdir=LR; splines=true; node [shape=circle];\n" +
               "  q0 [label=\"q0 (inicio)\"]; q1; q2; q3; q4; q6 [shape=doublecircle,label=\"q6 (acept)\"];\n" +
               "  q0 -> q1 [label=\"ε\"]; q0 -> q2 [label=\"ε\"];\n" +
               "  q1 -> q3 [label=\"+ | -\"];\n" +
               "  q2 -> q6 [label=\"0\"]; q3 -> q6 [label=\"0\"];\n" +
               "  q2 -> q4 [label=\"1–9\"]; q3 -> q4 [label=\"1–9\"];\n" +
               "  q4 -> q4 [label=\"0–9\"]; q4 -> q6 [label=\"ε\"];\n" +
               "}\n";
    }

    public static String dotAFNVariable() {
        return "digraph VARIABLE {\n" +
               "  rankdir=LR; node [shape=circle];\n" +
               "  v0 [label=\"v0 (inicio)\"]; v1; v2; v3; v4 [shape=doublecircle,label=\"v4 (acept)\"];\n" +
               "  v0 -> v1 [label=\"A–Z | a–z\"];\n" +
               "  v1 -> v4 [label=\"ε\"]; v1 -> v2 [label=\"ε\"];\n" +
               "  v2 -> v3 [label=\"_\"]; v3 -> v3 [label=\"0–9\"]; v3 -> v4 [label=\"ε\"];\n" +
               "}\n";
    }

    public static String dotAFNExponente() {
        return "digraph EXPONENTE {\n" +
               "  rankdir=LR; node [shape=circle];\n" +
               "  e0 [label=\"e0 (inicio)\"]; e1; e2; e3; e4; e5; e6 [shape=doublecircle,label=\"e6 (acept)\"];\n" +
               "  e0 -> e1 [label=\"^\"];\n" +
               "  e1 -> e2 [label=\"ε\"]; e1 -> e3 [label=\"ε\"];\n" +
               "  e2 -> e4 [label=\"+ | -\"];\n" +
               "  e3 -> e6 [label=\"0\"]; e4 -> e6 [label=\"0\"];\n" +
               "  e3 -> e5 [label=\"1–9\"]; e4 -> e5 [label=\"1–9\"]; e5 -> e5 [label=\"0–9\"]; e5 -> e6 [label=\"ε\"];\n" +
               "}\n";
    }

    public static String dotAFNOperador() {
        return "digraph OPERADOR {\n" +
               "  rankdir=LR; node [shape=circle];\n" +
               "  o0 [label=\"o0 (inicio)\"]; o1 [shape=doublecircle,label=\"o1 (acept)\"];\n" +
               "  o0 -> o1 [label=\"+ | - | * | /\"];\n" +
               "}\n";
    }

    public static String dotAFNParenIzq() {
        return "digraph LPAREN {\n" +
               "  rankdir=LR; node [shape=circle];\n" +
               "  p0 [label=\"p0 (inicio)\"]; p1 [shape=doublecircle,label=\"p1 (acept)\"];\n" +
               "  p0 -> p1 [label=\"(\"];\n" +
               "}\n";
    }

    public static String dotAFNParenDer() {
        return "digraph RPAREN {\n" +
               "  rankdir=LR; node [shape=circle];\n" +
               "  p2 [label=\"p2 (inicio)\"]; p3 [shape=doublecircle,label=\"p3 (acept)\"];\n" +
               "  p2 -> p3 [label=\")\"];\n" +
               "}\n";
    }

    public static String dotAFNWhitespace() {
        return "digraph WHITESPACE {\n" +
               "  rankdir=LR; node [shape=circle];\n" +
               "  w0 [label=\"w0 (inicio)\"]; w1 [shape=doublecircle,label=\"w1 (acept)\"];\n" +
               "  w0 -> w1 [label=\"␠ | \\\\t | \\\\r | \\\\n\"]; w1 -> w1 [label=\"␠ | \\\\t | \\\\r | \\\\n\"];\n" +
               "}\n";
    }

    // ========= AFN GLOBAL (macro) =========
    public static String dotAFNGlobal() {
        return "digraph AFN_GLOBAL {\n" +
               "  rankdir=LR; splines=true; node [shape=circle];\n" +
               "  S [label=\"S (inicio global)\", style=\"bold\"];\n" +
               "  subgraph cluster_coef {label=\"COEFICIENTE\"; style=dashed; c_i [label=\"c_i\"]; c_f [shape=doublecircle,label=\"c_f\"]; }\n" +
               "  subgraph cluster_var  {label=\"VARIABLE\";   style=dashed; v_i [label=\"v_i\"]; v_f [shape=doublecircle,label=\"v_f\"]; }\n" +
               "  subgraph cluster_exp  {label=\"EXPONENTE\";  style=dashed; e_i [label=\"e_i\"]; e_f [shape=doublecircle,label=\"e_f\"]; }\n" +
               "  subgraph cluster_op   {label=\"OPERADOR\";   style=dashed; o_i [label=\"o_i\"]; o_f [shape=doublecircle,label=\"o_f\"]; }\n" +
               "  subgraph cluster_lp   {label=\"LPAREN\";     style=dashed; l_i [label=\"l_i\"]; l_f [shape=doublecircle,label=\"l_f\"]; }\n" +
               "  subgraph cluster_rp   {label=\"RPAREN\";     style=dashed; r_i [label=\"r_i\"]; r_f [shape=doublecircle,label=\"r_f\"]; }\n" +
               "  subgraph cluster_ws   {label=\"WHITESPACE\"; style=dashed; w_i [label=\"w_i\"]; w_f [shape=doublecircle,label=\"w_f\"]; }\n" +
               "  S -> c_i [label=\"ε\"]; S -> v_i [label=\"ε\"]; S -> e_i [label=\"ε\"]; S -> o_i [label=\"ε\"]; S -> l_i [label=\"ε\"]; S -> r_i [label=\"ε\"]; S -> w_i [label=\"ε\"];\n" +
               "}\n";
    }

    // ========= Autómata lineal que acepta exactamente la secuencia de tokens de la ENTRADA =========
    private static String esc(String s) {
        if (s == null) return "";
        // escapar comillas y backslashes para DOT
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    public static String dotAutomataLinea(String input, List<Token> tokens) {
        StringBuilder sb = new StringBuilder();
        sb.append("digraph CADENA {\n  rankdir=LR; node [shape=circle];\n");
        sb.append("  s0 [label=\"s0 (inicio)\"]; \n");
        for (int i = 0; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            String from = "s" + i;
            String to = "s" + (i + 1);
            String lab = t.type + ":" + esc(t.lexeme);
            sb.append("  ").append(from).append(" -> ").append(to)
              .append(" [label=\"").append(lab).append("\"];\n");
        }
        sb.append("  s").append(tokens.size())
          .append(" [shape=doublecircle,label=\"s").append(tokens.size()).append(" (acept)\"];\n");
        sb.append("  label=\"Autómata lineal — Entrada: ").append(esc(input)).append("\";\n");
        sb.append("}\n");
        return sb.toString();
    }

    // ========= Guardar todos los .dot a /out/diagrams =========
    public static void exportAllDot(String input, List<Token> tokens) throws IOException {
        Path base = Path.of("out", "diagrams");
        DotIO.writeDot(dotAFNCoeficiente(), base.resolve("afn_coeficiente.dot"));
        DotIO.writeDot(dotAFNVariable(),    base.resolve("afn_variable.dot"));
        DotIO.writeDot(dotAFNExponente(),   base.resolve("afn_exponente.dot"));
        DotIO.writeDot(dotAFNOperador(),    base.resolve("afn_operador.dot"));
        DotIO.writeDot(dotAFNParenIzq(),    base.resolve("afn_lparen.dot"));
        DotIO.writeDot(dotAFNParenDer(),    base.resolve("afn_rparen.dot"));
        DotIO.writeDot(dotAFNWhitespace(),  base.resolve("afn_whitespace.dot"));
        DotIO.writeDot(dotAFNGlobal(),      base.resolve("afn_global.dot"));
        DotIO.writeDot(dotAutomataLinea(input, tokens), base.resolve("dfa_lineal.dot"));
    }
}
