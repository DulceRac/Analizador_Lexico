import java.awt.BorderLayout;
import java.awt.Font;
import java.util.List;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Analizador Léxico — Expresiones Algebraicas");
            JTextArea input = new JTextArea("3a + (b^2) - 10");
            input.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));

            JTextArea output = new JTextArea();
            output.setEditable(false);
            output.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

            JButton btnTokens = new JButton("Tokenizar + Validar sintaxis");
            JButton btnDiagramas = new JButton("Generar diagramas (.dot)");

            JPanel top = new JPanel(new BorderLayout());
            top.add(new JScrollPane(input), BorderLayout.CENTER);

            JPanel actions = new JPanel();
            actions.add(btnTokens);
            actions.add(btnDiagramas);
            top.add(actions, BorderLayout.SOUTH);

            f.setLayout(new BorderLayout());
            f.add(top, BorderLayout.CENTER);
            f.add(new JScrollPane(output), BorderLayout.SOUTH);

            // ---- Tokenizar + validar sintaxis ----
            btnTokens.addActionListener(e -> {
                try {
                    Lexer lx = new Lexer();
                    List<Token> toks = lx.tokenize(input.getText());

                    // 1) Mostrar tokens
                    StringBuilder sb = new StringBuilder();
                    sb.append("TOKENS:\n");
                    for (Token t : toks) sb.append(t).append("\n");

                    // 2) Validar SINTAXIS con Parser
                    try {
                        new Parser(toks).parse();
                        sb.append("\nSINTAXIS: OK ");
                        // limpiar selección si todo bien
                        input.requestFocus();
                        input.select(0, 0);
                    } catch (Parser.SyntaxError se) {
                        sb.append("\nSINTAXIS: ERROR \n").append(se.getMessage());
                        // Resaltar donde falló
                        int pos = se.pos;
                        if (pos >= 0 && pos < input.getText().length()) {
                            input.requestFocus();
                            input.select(pos, Math.min(pos + 1, input.getText().length()));
                        }
                    }

                    output.setText(sb.toString());

                } catch (RuntimeException exLex) {
                    // Error LÉXICO
                    output.setText("LEXICO: ERROR \n" + exLex.getMessage());
                    int pos = extraerPosicionDeError(exLex.getMessage());
                    if (pos >= 0 && pos < input.getText().length()) {
                        input.requestFocus();
                        input.select(pos, Math.min(pos + 1, input.getText().length()));
                    }
                }
            });

            // ---- Generar diagramas .dot ----
            btnDiagramas.addActionListener(e -> {
                try {
                    Lexer lx = new Lexer();
                    List<Token> toks = lx.tokenize(input.getText());
                    DiagramGenerator.exportAllDot(input.getText(), toks);
                    output.setText("Diagramas .dot generados en: out/diagrams\n" +
                                   " - afn_*.dot (por token)\n" +
                                   " - afn_global.dot\n" +
                                   " - dfa_lineal.dot (traza de la entrada)\n" +
                                   "Abre los .dot en Graphviz Online o con: dot -Tpng archivo.dot -o salida.png");
                } catch (Exception ex2) {
                    output.setText("ERROR: " + ex2.getMessage());
                }
            });

            f.setSize(720, 520);
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        });
    }

    // Extrae el número después de "posición" en el mensaje de error léxico
    private static int extraerPosicionDeError(String msg) {
        try {
            int idx = msg.indexOf("posición");
            if (idx < 0) return -1;
            int i = idx + "posición".length();
            while (i < msg.length() && Character.isWhitespace(msg.charAt(i))) i++;
            int j = i;
            while (j < msg.length() && Character.isDigit(msg.charAt(j))) j++;
            return Integer.parseInt(msg.substring(i, j));
        } catch (Exception e) {
            return -1;
        }
    }
}
