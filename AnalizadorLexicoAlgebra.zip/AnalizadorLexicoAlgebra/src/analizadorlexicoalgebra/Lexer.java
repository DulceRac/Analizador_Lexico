import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lexer {

    private static final class Rule {
        final Pattern pattern;
        final TokenType type;
        final int priority; // menor = mayor prioridad
        Rule(String regex, TokenType type, int priority) {
            this.pattern = Pattern.compile(regex);
            this.type = type;
            this.priority = priority;
        }
    }

    // NOTA: COEFICIENTE AHORA NO TIENE SIGNO  (+/- se tokenizan como OPERADOR)
    private static final List<Rule> RULES = Arrays.asList(
        new Rule("[ \\t\\r\\n]+",                TokenType.WHITESPACE, 1),
        new Rule("\\(",                         TokenType.LPAREN,     2),
        new Rule("\\)",                         TokenType.RPAREN,     2),
        new Rule("[+\\-*/]",                    TokenType.OPERADOR,   3),
        new Rule("\\^[+\\-]?(?:[1-9][0-9]*|0)", TokenType.EXPONENTE,  4),
        new Rule("(?:[1-9][0-9]*|0)",           TokenType.COEFICIENTE,5),
        new Rule("[a-zA-Z](?:_[0-9]+)?",        TokenType.VARIABLE,   6)
    );

    public List<Token> tokenize(String input) {
        List<Token> out = new ArrayList<>();
        int pos = 0;
        final int n = input.length();

        while (pos < n) {
            int bestLen = -1;
            Rule bestRule = null;
            String bestLex = null;

            for (Rule r : RULES) {
                Matcher m = r.pattern.matcher(input);
                m.region(pos, n); // obligar a iniciar en pos
                if (m.lookingAt()) {
                    String lex = m.group();
                    int len = lex.length();
                    if (len > 0) {
                        if (bestRule == null || len > bestLen ||
                           (len == bestLen && r.priority < bestRule.priority)) {
                            bestLen = len;
                            bestRule = r;
                            bestLex = lex;
                        }
                    }
                }
            }

            if (bestRule == null) {
                char errorChar = input.charAt(pos);
                String contexto = input.substring(Math.max(0, pos - 3), Math.min(n, pos + 5));
                throw new RuntimeException(
                    "Error léxico en posición " + pos +
                    " (carácter inválido: '" + errorChar + "')\n" +
                    "Contexto: ..." + contexto + "..."
                );
            }

            if (bestRule.type != TokenType.WHITESPACE) {
                out.add(new Token(bestRule.type, bestLex, pos, pos + bestLen));
            }
            pos += bestLen;
        }
        return out;
    }
}
