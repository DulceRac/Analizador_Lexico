public class Token {
    public final TokenType type;
    public final String lexeme;
    public final int start, end;

    public Token(TokenType type, String lexeme, int start, int end) {
        this.type = type;
        this.lexeme = lexeme;
        this.start = start;
        this.end = end;
    }
    @Override public String toString() {
        return "[" + type + ":" + lexeme + "]";
    }
}
