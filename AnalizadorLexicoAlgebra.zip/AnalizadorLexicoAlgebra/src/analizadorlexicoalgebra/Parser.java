import java.util.List;

public class Parser {
    private final List<Token> tokens;
    private int i = 0;

    public static class SyntaxError extends RuntimeException {
        public final int pos;
        public SyntaxError(String msg, int pos) {
            super(msg + " [pos=" + pos + "]");
            this.pos = pos;
        }
    }

    public Parser(List<Token> tokens) { this.tokens = tokens; }

    // Entrada
    public void parse() {
        if (tokens.isEmpty()) throw new SyntaxError("Expresión vacía", 0);
        parseExpression();
        if (!isAtEnd()) {
            Token t = peek();
            throw new SyntaxError("Símbolo inesperado después de una expresión completa: "
                    + t.type + " '" + t.lexeme + "'", t.start);
        }
    }

    // EXPRESION -> TERMINO ( (+|-) TERMINO )*
    private void parseExpression() {
        parseTerm();
        while (matchOp("+") || matchOp("-")) {
            if (isAtEnd()) throw new SyntaxError("Operador '" + prev().lexeme + "' sin término a la derecha", prev().start);
            parseTerm();
        }
    }

    // TERMINO -> UNARIO ( (*|/) UNARIO )*
    private void parseTerm() {
        parseUnary();
        while (matchOp("*") || matchOp("/")) {
            if (isAtEnd()) throw new SyntaxError("Operador '" + prev().lexeme + "' sin factor a la derecha", prev().start);
            parseUnary();
        }
    }

    // UNARIO -> (+|-) * UNARIO | FACTOR
    private void parseUnary() {
        while (matchOp("+") || matchOp("-")) {
            // consumir todos los signos unarios encadenados
        }
        parseFactor();
    }

    // FACTOR -> COEFICIENTE? VARIABLE EXPONENTE?
    //         | COEFICIENTE
    //         | ( EXPRESION )
    private void parseFactor() {
        if (match(TokenType.LPAREN)) {
            parseExpression();
            if (!match(TokenType.RPAREN)) {
                Token t = isAtEnd() ? prev() : peek();
                int pos = isAtEnd() ? prev().end : t.start;
                throw new SyntaxError("Falta ')' para cerrar paréntesis", pos);
            }
            return;
        }

        int save = i;

        // COEFICIENTE? VARIABLE EXPONENTE?
        if (match(TokenType.COEFICIENTE)) {
            if (match(TokenType.VARIABLE)) {
                match(TokenType.EXPONENTE); // opcional
                return;
            } else {
                // Solo número también es factor válido
                return;
            }
        }

        i = save;
        if (match(TokenType.VARIABLE)) {
            match(TokenType.EXPONENTE); // opcional
            return;
        }

        Token t = isAtEnd() ? prev() : peek();
        int pos = isAtEnd() ? (prev() != null ? prev().end : 0) : t.start;
        throw new SyntaxError("Se esperaba un FACTOR (número, variable o '(' )", pos);
    }

    // utilidades
    private boolean isAtEnd() { return i >= tokens.size(); }
    private Token peek() { return tokens.get(i); }
    private Token prev() { return tokens.get(i - 1); }

    private boolean match(TokenType type) {
        if (isAtEnd()) return false;
        if (tokens.get(i).type == type) { i++; return true; }
        return false;
    }

    private boolean matchOp(String op) {
        if (isAtEnd()) return false;
        Token t = tokens.get(i);
        if (t.type == TokenType.OPERADOR && t.lexeme.equals(op)) {
            i++;
            return true;
        }
        return false;
    }
}
